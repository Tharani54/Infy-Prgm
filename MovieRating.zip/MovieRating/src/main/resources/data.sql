insert into Rating values (1,'Movie 2',4.0,'tharani',3,'manoharan');
insert into Rating values (2,'Movie 3',3.0,'Madhan',2,'Durai');
insert into Rating values (3,'Movie 1',4.0,'Varshini',1,'Prabhakar');
insert into Rating Values (4,'Movie 3',3.0,'tharani',3,'manoharan');
insert into Rating Values (5,'Movie 1',3.0,'tharani',3,'manoharan');